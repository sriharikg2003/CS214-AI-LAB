Keep all these files in the same directory to run the files named heur1.py and heur2.py

The Python version used while implementing this code is Python 3.10.9

Heuristic 1 is applied in heur1.py and Heuristic 2 is applied in heur2.py

Authors: Tejas(210030039) and Srihari(210030035) 

Input should be in the same order as seen from top to bottom of a stack from left to right using comma separated entries

If no block exists then, leave it blank by a comma but without any space.

Instance 1

A
B C
D E F

Input is 
ABD,CE,F


Instance 2

A
B   C

Input is 
AB,,C

Note : In the output Elements from top to bottom of a stack are printed from right to left
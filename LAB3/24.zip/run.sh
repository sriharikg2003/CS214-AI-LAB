#!/bin/bash
python 24.py $1

To run the code successfully :
Type in the terminal as

bash run.sh file_name



Example
file_name could be euc_100 
then type
bash run.sh euc_100
